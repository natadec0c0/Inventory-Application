package org.apache.commons.javaflow.bytecode.transformation.data;

import java.io.Serializable;
import org.apache.commons.javaflow.Continuation;


public final class SimpleSerializable implements Runnable, Serializable {
    private static final long serialVersionUID = 1L;
    
    public int g = -1; // global count throughout all continuations
    public int l = -1; // local count mapped to a global variable so
                       // we can access is
    
    public void run() {
        int local = -1;
        ++g; l=++local;
        Continuation.suspend();
        ++g; l=++local;
        Continuation.suspend();
        ++g; l=++local;
        Continuation.suspend();
        ++g; l=++local;
    }

}

