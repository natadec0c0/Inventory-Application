package org.apache.commons.javaflow.bytecode.transformation.data;

import org.apache.commons.javaflow.Continuation;


/**
 * @author Kohsuke Kawaguchi
 */
public final class CounterFlow implements Runnable {

  final int up;

  public CounterFlow( int up) {
    this.up = up;
  }

  public void run() {
    for( int i = 0; i < up; i++) {
      System.err.println(i);
      Continuation.suspend();
    }
  }
}

