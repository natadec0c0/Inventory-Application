package org.apache.commons.javaflow.bytecode.transformation.tests;

import org.apache.commons.javaflow.Continuation;
import org.apache.commons.javaflow.bytecode.transformation.AbstractTransformerTestCase;
import org.apache.commons.javaflow.bytecode.transformation.data.ClassAccess1;
import org.apache.commons.javaflow.bytecode.transformation.data.ClassAccess2;

public abstract class AbstractClassAccessTestCase extends AbstractTransformerTestCase {

    public void testClassAccess1() throws Exception {
        final ClassAccess1 r = new ClassAccess1();
        final Continuation c = Continuation.startWith(r);
        assertTrue(c != null);
    }
    
    public void testClassAccess2() throws Exception {
        final ClassAccess2 r = new ClassAccess2();
        final Continuation c = Continuation.startWith(r);
        assertTrue(c != null);
    }
}
