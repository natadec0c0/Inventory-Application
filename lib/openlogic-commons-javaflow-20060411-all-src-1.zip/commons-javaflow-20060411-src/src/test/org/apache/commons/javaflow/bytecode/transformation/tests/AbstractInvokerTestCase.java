package org.apache.commons.javaflow.bytecode.transformation.tests;

import org.apache.commons.javaflow.Continuation;
import org.apache.commons.javaflow.bytecode.transformation.AbstractTransformerTestCase;
import org.apache.commons.javaflow.bytecode.transformation.Invoker;

public abstract class AbstractInvokerTestCase extends AbstractTransformerTestCase {

    public void testInvoker() {
        Runnable r = new Thread();
        Runnable o = new Invoker(r);
        Continuation c = Continuation.startWith(o);
        assertTrue(c != null);
    }
}
