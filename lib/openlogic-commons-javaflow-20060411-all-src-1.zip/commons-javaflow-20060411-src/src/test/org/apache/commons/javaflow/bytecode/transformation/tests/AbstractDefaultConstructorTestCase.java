package org.apache.commons.javaflow.bytecode.transformation.tests;

import junit.framework.TestCase;
import org.apache.commons.javaflow.Continuation;
import org.apache.commons.javaflow.bytecode.transformation.data.DefaultConstructor;

public class AbstractDefaultConstructorTestCase extends TestCase {

    public void testInvoker() {
        Runnable o = new DefaultConstructor();
        Continuation c = Continuation.startWith(o);
        assertTrue(c == null);
    }
}
