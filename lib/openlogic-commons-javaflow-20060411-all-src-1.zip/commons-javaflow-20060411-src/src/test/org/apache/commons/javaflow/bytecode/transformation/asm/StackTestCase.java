package org.apache.commons.javaflow.bytecode.transformation.asm;

import junit.framework.Test;
import junit.framework.TestSuite;
import org.apache.commons.javaflow.bytecode.transformation.tests.AbstractStackTestCase;


public final class StackTestCase extends AbstractStackTestCase {
 
    public static Test suite() throws Exception {
        final Class test = StackTestCase.class;
        final AsmClassTransformerClassLoader classloader =
            new AsmClassTransformerClassLoader(test.getPackage().getName());
        final Class clazz = classloader.loadClass(test.getName());
        return new TestSuite(clazz);
    }
 
}
