package org.apache.commons.javaflow.bytecode.transformation.tests;

import org.apache.commons.javaflow.bytecode.transformation.AbstractTransformerTestCase;


public final class RewritingTestCase extends AbstractTransformerTestCase {

//    public void testBlackRed() throws Exception {
//        assertSameTransformation("org.apache.commons.javaflow.bytecode.transformation.data.BlackRed");
//    }
//    public void testClassAccess1() throws Exception {
//        assertSameTransformation("org.apache.commons.javaflow.bytecode.transformation.data.ClassAccess1");
//    }
//    public void testClassAccess2() throws Exception {
//        assertSameTransformation("org.apache.commons.javaflow.bytecode.transformation.data.ClassAccess2");
//    }
//    public void testClassAccess3() throws Exception {
//        assertSameTransformation("org.apache.commons.javaflow.bytecode.transformation.data.ClassAccess3");
//    }
//    public void testCounterFlow() throws Exception {
//        assertSameTransformation("org.apache.commons.javaflow.bytecode.transformation.data.CounterFlow");
//    }
//    public void testDefaultConstructor() throws Exception {
//        assertSameTransformation("org.apache.commons.javaflow.bytecode.transformation.data.DefaultConstructor");
//    }
//    public void testNewObject() throws Exception {
//        assertSameTransformation("org.apache.commons.javaflow.bytecode.transformation.data.NewObject");
//    }
//    public void testNoReference() throws Exception {
//        assertSameTransformation("org.apache.commons.javaflow.bytecode.transformation.data.NoReference");
//    }
//    public void testNullVariableMethodFlow() throws Exception {
//        assertSameTransformation("org.apache.commons.javaflow.bytecode.transformation.data.NullVariableMethodFlow");
//    }
//    public void testSimple() throws Exception {
//        assertSameTransformation("org.apache.commons.javaflow.bytecode.transformation.data.Simple");
//    }
//    public void testSimpleSerializable() throws Exception {
//        assertSameTransformation("org.apache.commons.javaflow.bytecode.transformation.data.SimpleSerializable");
//    }
//    public void testStack() throws Exception {
//        assertSameTransformation("org.apache.commons.javaflow.bytecode.transformation.data.Stack");
//    }
}
