package org.apache.commons.javaflow.bytecode.transformation.tests;

import junit.framework.TestCase;
import org.apache.commons.javaflow.bytecode.transformation.data.Simple;



public final class UsageTestCase extends TestCase {
    
    public void testIncorrectUsageWithNormalClassLoader() throws Exception {
        try {
            final Runnable r = new Simple();
            r.run();
            fail();
        } catch (final Exception e) {
            assertTrue(e instanceof IllegalStateException);
        }
    }
    
}
