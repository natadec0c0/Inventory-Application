package org.apache.commons.javaflow.bytecode.transformation.data;

import org.apache.commons.javaflow.Continuation;

public final class ClassAccess3 implements Runnable {

    /*
       L0 (0)
        GETSTATIC ClassAccess2.class$0 : Class
        DUP
        IFNONNULL L1
        POP
       
       L2 (5)
        LDC "asm.data.ClassAccess2"
        INVOKESTATIC Class.forName(String) : Class
       
       L3 (8)
        DUP
        PUTSTATIC ClassAccess2.class$0 : Class
        GOTO L1
       
       L4 (12)
        NEW NoClassDefFoundError
        DUP_X1
        SWAP
        INVOKEVIRTUAL Throwable.getMessage() : String
        INVOKESPECIAL NoClassDefFoundError.<init>(String) : void
        ATHROW
       
       L1 (19)
        ASTORE 1: clazz1
       L5 (21)
        INVOKESTATIC Continuation.suspend() : void
       L6 (23)
        RETURN

       L7 (25)
        TRYCATCHBLOCK L2 L3 L4 ClassNotFoundException
     */
  
    static Class class$0;
  
    public void run() {
        // final Class clazz1 = ClassAccess2.class;
        // final Class clazz2 = this.getClass();
        // if(class$0==null) {
          try {
            class$0 = Class.forName("asm.data.ClassAccess2");
          } catch(ClassNotFoundException ex) {
            throw new NoClassDefFoundError(ex.getMessage());
          }
        // }
        
        Continuation.suspend();
    }

}