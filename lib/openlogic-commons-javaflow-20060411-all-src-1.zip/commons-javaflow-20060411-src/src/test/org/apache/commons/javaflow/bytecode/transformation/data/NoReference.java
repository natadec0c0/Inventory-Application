package org.apache.commons.javaflow.bytecode.transformation.data;

import org.apache.commons.javaflow.Continuation;


public final class NoReference implements Runnable {

  public void run() {
    new Object();
    Continuation.suspend();
  }

}