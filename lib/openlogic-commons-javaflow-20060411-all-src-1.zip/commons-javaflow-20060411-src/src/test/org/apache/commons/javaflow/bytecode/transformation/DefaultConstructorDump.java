package org.apache.commons.javaflow.bytecode.transformation;

import org.objectweb.asm.AnnotationVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;


public class DefaultConstructorDump implements Opcodes {

  public static byte[] dump() throws Exception {
    FieldVisitor fv;
    MethodVisitor mv;
    AnnotationVisitor av0;

    ClassWriter cw = new ClassWriter(true);
    cw.visit( V1_2, ACC_PUBLIC + ACC_FINAL + ACC_SUPER, "org/apache/commons/javaflow/bytecode/transformation/asm/data/DefaultConstructor", null, "java/lang/Thread", null);

    cw.visitSource( "DefaultConstructor.java", null);

    {
      mv = cw.visitMethod( ACC_PUBLIC, "<init>", "()V", null, null);
      mv.visitCode();
      
      Label l0 = new Label();
      mv.visitLabel( l0);
      
      mv.visitVarInsn( ALOAD, 0);
      mv.visitMethodInsn( INVOKESPECIAL, "java/lang/Thread", "<init>", "()V");

      mv.visitMethodInsn( INVOKESTATIC, "org/apache/commons/javaflow/bytecode/StackRecorder", "get", "()Lorg/apache/commons/javaflow/bytecode/StackRecorder;");
      mv.visitInsn( DUP);
      mv.visitVarInsn( ASTORE, 1);
      Label l1 = new Label();
      mv.visitJumpInsn( IFNULL, l1);
      mv.visitVarInsn( ALOAD, 1);
      mv.visitMethodInsn( INVOKEVIRTUAL, "org/apache/commons/javaflow/bytecode/StackRecorder", "isRestoring", "()Z");
      mv.visitJumpInsn( IFEQ, l1);
      mv.visitVarInsn( ALOAD, 1);
      mv.visitMethodInsn( INVOKEVIRTUAL, "org/apache/commons/javaflow/bytecode/StackRecorder", "popInt", "()I");
      Label l2 = new Label();
      mv.visitTableSwitchInsn( 0, 0, l1, new Label[] { l2});
      
      mv.visitLabel( l2);
      mv.visitLdcInsn( "restore locals");
      mv.visitInsn( POP);
      mv.visitVarInsn( ALOAD, 1);
      mv.visitMethodInsn( INVOKEVIRTUAL, "org/apache/commons/javaflow/bytecode/StackRecorder", "popObject", "()Ljava/lang/Object;");
      mv.visitTypeInsn( CHECKCAST, "org/apache/commons/javaflow/bytecode/transformation/asm/data/DefaultConstructor");
      mv.visitVarInsn( ASTORE, 0);
      mv.visitLdcInsn( "restore stack");
      mv.visitInsn( POP);
      mv.visitLdcInsn( "restore reference");
      mv.visitInsn( POP);
      mv.visitVarInsn( ALOAD, 1);
      mv.visitMethodInsn( INVOKEVIRTUAL, "org/apache/commons/javaflow/bytecode/StackRecorder", "popReference", "()Ljava/lang/Object;");
      mv.visitTypeInsn( CHECKCAST, "java/io/PrintStream");
      mv.visitLdcInsn( "restore params");
      mv.visitInsn( POP);
      mv.visitInsn( ACONST_NULL);
      mv.visitTypeInsn( CHECKCAST, "java/lang/String");
      Label l3 = new Label();
      mv.visitJumpInsn( GOTO, l3);
      
      mv.visitLabel( l1);
      
      mv.visitFieldInsn( GETSTATIC, "java/lang/System", "err", "Ljava/io/PrintStream;");
      mv.visitLdcInsn( "aaa");
      mv.visitLabel( l3);
      mv.visitMethodInsn( INVOKEVIRTUAL, "java/io/PrintStream", "println", "(Ljava/lang/String;)V");
      mv.visitVarInsn( ALOAD, 1);
      Label l5 = new Label();
      mv.visitJumpInsn( IFNULL, l5);
      mv.visitVarInsn( ALOAD, 1);
      mv.visitMethodInsn( INVOKEVIRTUAL, "org/apache/commons/javaflow/bytecode/StackRecorder", "isCapturing", "()Z");
      mv.visitJumpInsn( IFEQ, l5);
      mv.visitVarInsn( ALOAD, 1);
      mv.visitVarInsn( ALOAD, 0);
      mv.visitMethodInsn( INVOKEVIRTUAL, "org/apache/commons/javaflow/bytecode/StackRecorder", "pushReference",
          "(Ljava/lang/Object;)V");
      mv.visitVarInsn( ALOAD, 1);
      mv.visitVarInsn( ALOAD, 0);
      mv.visitMethodInsn( INVOKEVIRTUAL, "org/apache/commons/javaflow/bytecode/StackRecorder", "pushObject",
          "(Ljava/lang/Object;)V");
      mv.visitVarInsn( ALOAD, 1);
      mv.visitIntInsn( BIPUSH, 0);
      mv.visitMethodInsn( INVOKEVIRTUAL, "org/apache/commons/javaflow/bytecode/StackRecorder", "pushInt", "(I)V");
      mv.visitInsn( RETURN);
      
      mv.visitLabel( l5);
      mv.visitInsn( RETURN);
      
      Label l6 = new Label();
      mv.visitLabel( l6);
      mv.visitLocalVariable( "this", "Lorg/apache/commons/javaflow/bytecode/transformation/asm/data/DefaultConstructor;", null, l1, l6, 0);
      mv.visitLocalVariable( "__stackRecorder", "Lorg/apache/commons/javaflow/bytecode/StackRecorder;", null, l0, l6, 1);
      mv.visitMaxs( 2, 2);
      mv.visitEnd();
    }
    cw.visitEnd();

    return cw.toByteArray();
  }
}

