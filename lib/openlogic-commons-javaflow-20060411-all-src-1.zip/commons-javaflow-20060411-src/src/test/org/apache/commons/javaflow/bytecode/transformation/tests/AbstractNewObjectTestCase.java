package org.apache.commons.javaflow.bytecode.transformation.tests;

import org.apache.commons.javaflow.Continuation;
import org.apache.commons.javaflow.bytecode.transformation.AbstractTransformerTestCase;
import org.apache.commons.javaflow.bytecode.transformation.data.NewObject;

public abstract class AbstractNewObjectTestCase extends AbstractTransformerTestCase {

    public void testNewObject() throws Exception {
        final Runnable r = new NewObject();
        final Continuation c = Continuation.startWith(r);
        assertTrue(c == null);
    }
}
