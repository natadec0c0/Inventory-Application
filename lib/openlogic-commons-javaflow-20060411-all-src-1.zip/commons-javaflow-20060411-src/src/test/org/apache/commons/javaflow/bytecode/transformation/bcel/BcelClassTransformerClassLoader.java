package org.apache.commons.javaflow.bytecode.transformation.bcel;

import org.apache.commons.javaflow.bytecode.transformation.AbstractClassTransformerClassLoader;

public final class BcelClassTransformerClassLoader extends AbstractClassTransformerClassLoader {

    public BcelClassTransformerClassLoader( final String pPrefix ) {
        super(pPrefix, new BcelClassTransformer());
    }

}
