
package org.apache.commons.javaflow.bytecode.transformation.asm;

import org.apache.commons.javaflow.bytecode.transformation.AbstractClassTransformerClassLoader;


public class AsmClassTransformerClassLoader extends AbstractClassTransformerClassLoader {

    public AsmClassTransformerClassLoader( final String pPrefix ) {
        super(pPrefix, new AsmClassTransformer());
    }

}
