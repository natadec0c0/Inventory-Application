package org.apache.commons.javaflow.bytecode.transformation.tests;

import org.apache.commons.javaflow.Continuation;
import org.apache.commons.javaflow.bytecode.transformation.AbstractTransformerTestCase;
import org.apache.commons.javaflow.bytecode.transformation.data.NoReference;

public abstract class AbstractNoReferenceTestCase extends AbstractTransformerTestCase {

    public void testNoReference() throws Exception {
        final Runnable r = new NoReference();
        final Continuation c = Continuation.startWith(r);
        assertTrue(c != null);
    }
}
