package org.apache.commons.javaflow.bytecode.transformation.tests;

import org.apache.commons.javaflow.Continuation;
import org.apache.commons.javaflow.bytecode.transformation.AbstractTransformerTestCase;
import org.apache.commons.javaflow.bytecode.transformation.data.BlackRed;

public abstract class AbstractBlackRedTestCase extends AbstractTransformerTestCase {

    public void testBlackRed() {
        final Runnable r = new BlackRed();
        final Continuation c1 = Continuation.startWith(r);
        assertTrue(c1 != null);
        final Continuation c2 = Continuation.continueWith(c1);
        assertTrue(c2 == null);
    }
}
