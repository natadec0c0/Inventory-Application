package org.apache.commons.javaflow.bytecode.transformation.bcel;

import junit.framework.Test;
import junit.framework.TestSuite;
import org.apache.commons.javaflow.bytecode.transformation.tests.AbstractNoReferenceTestCase;


public final class NoReferenceTestCase extends AbstractNoReferenceTestCase {

    public static Test suite() throws Exception {
        final Class test = NoReferenceTestCase.class;
        final BcelClassTransformerClassLoader classloader =
            new BcelClassTransformerClassLoader(test.getPackage().getName());
        final Class clazz = classloader.loadClass(test.getName());
        return new TestSuite(clazz);
    }
   
}

