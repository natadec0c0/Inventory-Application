package org.apache.commons.javaflow.bytecode.transformation;


public final class Invoker implements Runnable {

    private Runnable runnable;
    
    public Invoker(Runnable runnable) {
        this.runnable = runnable;
    }
    
    public void run() {
        runnable.run();
    }
    
}
