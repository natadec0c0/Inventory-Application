package org.apache.commons.javaflow.bytecode.transformation.tests;

import org.apache.commons.javaflow.Continuation;
import org.apache.commons.javaflow.bytecode.transformation.AbstractTransformerTestCase;
import org.apache.commons.javaflow.bytecode.transformation.data.Stack;

public abstract class AbstractStackTestCase extends AbstractTransformerTestCase {

    public void testStack() throws Exception {
        final Runnable r = new Stack();
        final Continuation c = Continuation.startWith(r);
        assertTrue(c == null);
    }
}
