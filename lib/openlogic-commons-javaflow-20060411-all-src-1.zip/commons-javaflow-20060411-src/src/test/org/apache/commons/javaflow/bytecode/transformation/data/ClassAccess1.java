package org.apache.commons.javaflow.bytecode.transformation.data;

import org.apache.commons.javaflow.Continuation;

public final class ClassAccess1 implements Runnable {

    public void run() {
        final Class clazz1 = ClassAccess1.class;
        final Class clazz2 = this.getClass();
        
        Continuation.suspend();
    }

}