package org.apache.commons.javaflow.bytecode.transformation.data;


public final class DefaultConstructor implements Runnable {

    public DefaultConstructor() {
    }
    
    public void run() {
    }
    
}
