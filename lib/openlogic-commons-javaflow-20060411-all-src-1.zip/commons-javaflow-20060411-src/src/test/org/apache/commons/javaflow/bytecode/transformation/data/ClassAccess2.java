package org.apache.commons.javaflow.bytecode.transformation.data;


public final class ClassAccess2 implements Runnable {

    public void run() {
        Object o = ClassAccess2.class;
    }
    
}
